import logo from '../assets/investment-calculator-logo.png';

export default function Header (){
    return (
    <header>
        <img src={logo} alt="Logo showing money bank"/>
        <h1>Investment calculator</h1>
        </header>
        );
}