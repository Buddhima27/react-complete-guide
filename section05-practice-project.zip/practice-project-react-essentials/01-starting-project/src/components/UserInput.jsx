import {useState} from "react";
export default function UserInput({userInput, onChange}){
    return(
        <section id="user-input">
            <div className="input-group">
                <p>
                    <label>Initial investment</label>
                    <input type="number" required
                  onChange={(event) => onChange('initialInvestment', event.target.value)}/>
                </p>
                <p>
                    <label>Annual Investment</label>
                    <input type="number" required
                    value={userInput.annualInvestment}
                    onChange={(event) => onChange('annualInvestment', event.target.value)}
                    />
                    
                </p>
                  <p>
                    <label>Expected Return</label>
                    <input type="number" required
                     value={userInput.exepectedReturn}
                    onChange={(event) => onChange('exepectedReturn', event.target.value)}
                    />
                   
                </p>
                <p>
                    <label>Duration</label>
                    <input type="number" required
                     value={userInput.duration}
                    onChange={(event) => onChange('duration', event.target.value)}
                    />
                </p>
            </div>
        </section>
    )
}