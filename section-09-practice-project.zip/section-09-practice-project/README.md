# Section 9: Practice Project - Project Management App

A complete Project Management dashboard built with **React**, **Vite**, and **Tailwind CSS**, corresponding to **Section 9** of Maximilian Schwarzmüller's Udemy course: **[React - The Complete Guide (incl. Next.js, Redux)](https://www.udemy.com/course/react-the-complete-guide-incl-redux/)**.

---

## 🚀 Features

- **Project Management**: Add new projects with a title, description, and due date.
- **Form Validation with Native Dialog & Portals**: Validates inputs using React Portals (`createPortal`), `forwardRef`, and `useImperativeHandle` attached to the HTML `<dialog>` element.
- **Task Management**: Add and clear tasks associated with specific projects.
- **State Lifting & Management**: Clean project selection, active state highlighting in the sidebar, and filtering.
- **Modern Styling**: Polished UI with Tailwind CSS.

---

## 📁 Component Architecture

- `src/App.jsx`: Root component managing global state (`projectsState`), active view routing, project creation/deletion, and task addition/removal.
- `src/components/ProjectsSidebar.jsx`: Sidebar displaying the "+ Add Project" action and the list of user projects with active selection highlights.
- `src/components/NewProject.jsx`: Form with `useRef` to capture project values and modal error handling.
- `src/components/NoProjectSelected.jsx`: Empty-state placeholder with an action button to create a new project.
- `src/components/SelectedProject.jsx`: View displaying project details (title, formatted date, description) with delete option and tasks.
- `src/components/Tasks.jsx`: Sub-component rendering the project's task list or empty message.
- `src/components/NewTask.jsx`: Controlled component with `useState` to submit new tasks.
- `src/components/Modal.jsx`: Custom reusable dialog modal utilizing `forwardRef` + `useImperativeHandle` and `createPortal` to `#modal-root`.
- `src/components/Input.jsx`: Flexible input component rendering `<input>` or `<textarea>` based on props.
- `src/components/Button.jsx`: Reusable styled action button.

---

## 🛠️ Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Start the development server
```bash
npm run dev
```

### 3. Build for production
```bash
npm run build
```
