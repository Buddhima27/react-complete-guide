# Section 12: Practice Project - Building a React Quiz App

This is the completed solution for **Section 12: Practice Project** from Maximilian Schwarzmüller's Udemy course **"React - The Complete Guide (incl. Next.js, Redux)"**.

---

## 🎯 Project Features & Overview

The **ReactQuiz App** tests users on essential React concepts while illustrating real-world patterns for side effects, timers, and component state lifecycle management.

### Key Features:
- **Countdown Progress Bar**: Each question provides a 10-second timer rendered as a `<progress>` element.
- **Dynamic Answer States**: Provides immediate feedback states (`answered` ➔ `correct` / `wrong`) with distinct colors before transitioning to the next question.
- **Answer Shuffling**: Shuffles answers only once per question using `useRef` to maintain consistency across re-renders.
- **Auto-Skipping**: If time runs out, the question is automatically marked as skipped (`null`).
- **Detailed Summary Screen**: At the end, displays percentage statistics (skipped, correctly answered, incorrectly answered) alongside a comprehensive question-by-question breakdown.

---

## 💡 Key React Concepts Practiced

1. **Managing Side Effects with `useEffect`**:
   - Creating timeouts (`setTimeout`) and intervals (`setInterval`).
   - Implementing cleanup functions (`clearTimeout`, `clearInterval`) to avoid memory leaks.
2. **Preventing Infinite Loops with `useCallback`**:
   - Wrapping handler functions in `useCallback` so dependencies passed to child effects remain stable across re-renders.
3. **Persisting Values Across Renders with `useRef`**:
   - Using `useRef` in `Answers.jsx` to ensure randomized answer order doesn't change when the timer ticks or component re-renders.
4. **Strategic Use of the `key` Prop to Reset Component State**:
   - Passing `key={activeQuestionIndex}` to `<Question />` forces React to cleanly unmount the previous question and mount a new one, automatically resetting timers and internal selection state without messy manual reset logic.
5. **Derived State**:
   - Deriving active question index and quiz completion status (`userAnswers.length === QUESTIONS.length`) from existing state rather than duplicating state variables.

---

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Run the Development Server
```bash
npm run dev
```

### 3. Build for Production
```bash
npm run build
```

---

## 📤 Uploading to GitHub

To upload this completed project to your GitHub repository:

1. **Initialize Git (if not already initialized in your repo):**
   ```bash
   git init
   git add .
   git commit -m "Complete Section 12 Practice Project - React Quiz App"
   ```

2. **Add your remote repository URL & push:**
   ```bash
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   git branch -M main
   git push -u origin main
   ```
